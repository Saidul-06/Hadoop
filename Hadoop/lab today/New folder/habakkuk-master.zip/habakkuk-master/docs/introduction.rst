Introduction
============

Habakkuk is a tool intended for analysis and performance prediction of code
fragments (kernels) written in Fortran. Habakkuk is written in Python and
makes use of fparser (https://github.com/stfc/fparser), a Fortran parser.
